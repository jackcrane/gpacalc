<h1>Myschoolapp GPA injector</h1>
<hr>
This simple frontend GPA calculator automatically plugs in to yourschool.myschoolapp.com and calculates and injects your GPA to the "Performance" section. The calculator also automatically adds 1.33 for classes tagged as "AP" classes and 0.666 for classes tagged as "Honors" classes. This plugin automatically installs through the chrome webstore at the link below.


<a style="width:500px;height:100px;background-color:lightgreen" href="https://chrome.google.com/webstore/detail/myschoolapp-gpa-calculato/jfbodkjgjenlagkjepebmpnhekihgplo">Install the extension</a>


Some day I'll mess with the values so you can use custom weighting in settings as I'm aware not all schools use this specific GPA format. -c
